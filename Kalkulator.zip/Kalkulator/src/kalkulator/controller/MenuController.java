/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kalkulator.controller;

import kalkulator.view.InputBalok;
import kalkulator.view.InputBase;
import kalkulator.view.InputKubus;
import kalkulator.view.InputLimas;
import kalkulator.view.ShowBalok;
import kalkulator.view.ShowBase;
import kalkulator.view.ShowKubus;
import kalkulator.view.ShowLimas;

/**
 *
 * @author oktaviacitra
 */
public class MenuController {
    ShowBase showBase;
    InputBase inputBase;
    
    public MenuController() {
        showBase = new ShowBase();
        inputBase = new InputBase();
    }
    
    public void main() {
        showBase.title();
        showBase.menu();
        inputBase.inputMenu();
    }
    
    public int choice() {
        return inputBase.getMenu();
    }
    
    public void kubus() {
        InputKubus inputKubus = new InputKubus();
        inputKubus.input();
        ShowKubus showkubus = new ShowKubus(inputKubus.getKubus());
        showkubus.print();
    }
    
    public void balok() {
        InputBalok inputBalok = new InputBalok();
        inputBalok.input();
        ShowBalok showbalok = new ShowBalok(inputBalok.getBalok());
        showbalok.print();
    }
    
    public void limas() {
        InputLimas inputLimas = new InputLimas();
        inputLimas.input();
        ShowLimas showlimas = new ShowLimas(inputLimas.getLimas());
        showlimas.print();
    }
    
    public void exit() {
        System.out.println("Keluar dari program");
        System.exit(0);
    }
}

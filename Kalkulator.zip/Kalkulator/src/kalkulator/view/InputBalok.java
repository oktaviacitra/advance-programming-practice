/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kalkulator.view;
import kalkulator.model.Balok;
/**
 *
 * @author oktaviacitra
 */
public class InputBalok extends InputBase {
    float panjang;
    float lebar;
    
    public InputBalok(){
        super();
    }
    
    @Override
    public void input(){
        title();
        inputTinggi();
        System.out.print("Masukkan nilai panjang\t: ");
        panjang = scanner.nextFloat();
        System.out.print("Masukkan nilai lebar\t: ");
        lebar = scanner.nextFloat();
    }
    
    public Balok getBalok(){
        Balok balok = new Balok(panjang, lebar, tinggi);
        return balok;
    }
}

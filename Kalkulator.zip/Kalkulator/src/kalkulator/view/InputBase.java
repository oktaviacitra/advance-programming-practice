/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kalkulator.view;

import java.util.Scanner;

/**
 *
 * @author oktaviacitra
 */
public class InputBase {
    Scanner scanner = new Scanner(System.in);
    float tinggi;
    int menu;
    
    public InputBase(){
        this.tinggi = 0;
    }
    
    public void title(){
        System.out.println("MEMASUKKAN DATA");
        System.out.println("---------------");
    }
    
    public void inputMenu(){
        System.out.print("Masukkan pilihan menu\t: ");
        menu = scanner.nextInt();
    }
    
    public void inputTinggi(){
        System.out.print("Masukkan tinggi bangun\t: ");
        tinggi = scanner.nextFloat();
    }
    
    public int getMenu(){
        return menu;
    }
    
    public void input(){};
}

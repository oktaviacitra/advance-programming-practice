/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kalkulator.view;
import kalkulator.model.Balok;
/**
 *
 * @author oktaviacitra
 */
public class ShowBalok extends ShowBase{
    private Balok balok;
    
    public ShowBalok(){
        super();
    }
    
    public ShowBalok(Balok balok){
        this.balok = balok;
    }
    
    @Override
    public void print(){
        subtitle();
        System.out.println("Panjang\t: " + balok.getPanjang());
        System.out.println("Lebar\t: " + balok.getLebar());
        System.out.println("Tinggi\t: " + balok.getTinggi());
        System.out.println("Volume\t: " + balok.getVolume());
        separator();
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kalkulator.view;
import kalkulator.model.Limas;
/**
 *
 * @author oktaviacitra
 */
public class ShowLimas extends ShowBase {
    private Limas limas;
    
    public ShowLimas(){
        super();
    }
    
    public ShowLimas(Limas limas){
        this.limas = limas;
    }
    
    @Override
    public void print(){
        subtitle();
        System.out.println("Alas\t\t: " + limas.getAlas());
        System.out.println("Tinggi\t\t: " + limas.getTinggiSegi());
        System.out.println("Tinggi Limas\t: " + limas.getTinggi());
        System.out.println("Volume\t\t: "+ limas.getVolume());
        separator();
    }
}

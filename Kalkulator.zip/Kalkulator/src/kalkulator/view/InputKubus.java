/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kalkulator.view;
import kalkulator.model.Kubus;
/**
 *
 * @author oktaviacitra
 */
public class InputKubus extends InputBase {
    float sisi;
    
    public InputKubus(){
        super();
    }
    
    @Override
    public void input(){
        title();
        inputTinggi();
        System.out.print("Masukkan nilai sisi\t: ");
        sisi = scanner.nextFloat();
    }
    
    public Kubus getKubus(){
        Kubus kubus = new Kubus(sisi, tinggi);
        return kubus;
    }
}

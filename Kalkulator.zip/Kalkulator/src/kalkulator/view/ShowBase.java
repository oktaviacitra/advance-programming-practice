/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kalkulator.view;

/**
 *
 * @author oktaviacitra
 */
public class ShowBase {
    
    public ShowBase(){
        
    }
    
    public void title(){
        System.out.println("\tKALKULATOR VOLUME");
        System.out.println("\t=================");
    }
    
    public void menu(){
        System.out.println("1. Kubus");
        System.out.println("2. Balok");
        System.out.println("3. Limas");
        System.out.println("4. Keluar");
    }
    
    public void subtitle(){
        System.out.println("MENAMPILKAN DATA");
        System.out.println("----------------");
    }
    
    public void separator(){
        System.out.println("\n\n");
    }
    
    public void print(){};
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kalkulator.view;
import kalkulator.model.Kubus;
/**
 *
 * @author oktaviacitra
 */
public class ShowKubus extends ShowBase {
    private Kubus kubus;
    
    public ShowKubus() {
        super();
    }
    
    public ShowKubus(Kubus kubus) {
        this.kubus = kubus;
    }
    
    @Override
    public void print() {
        subtitle();
        System.out.println("Sisi\t: " + kubus.getSisi());
        System.out.println("Tinggi\t: " + kubus.getTinggi());
        System.out.println("Volume\t: " + kubus.getVolume());
        separator();
    }
}

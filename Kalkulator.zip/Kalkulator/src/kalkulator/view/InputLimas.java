/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kalkulator.view;
import kalkulator.model.Limas;
/**
 *
 * @author oktaviacitra
 */
public class InputLimas extends InputBase {
    float alas;
    float tinggiSegi;
    
    public InputLimas(){
        super();
    }
    
    @Override
    public void input(){
        title();
        inputTinggi();
        System.out.print("Masukkan nilai alas\t: ");
        alas = scanner.nextFloat();
        System.out.print("Masukkan nilai tinggi\t: ");
        tinggiSegi = scanner.nextFloat();
    }
    
    public Limas getLimas(){
        Limas limas = new Limas(alas, tinggiSegi, tinggi);
        return limas;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kalkulator.model;
/**
 *
 * @author oktaviacitra
 */
public class Limas extends BangunRuang{
    private float alas, tinggiSegi;
    
    public Limas() {
        super();
    }

    public Limas(float alas, float tinggiSegi) {
        this.alas = alas;
        this.tinggiSegi = tinggiSegi;
    }

    public Limas(float alas, float tinggiSegi, float tinggi) {
        super(tinggi);
        this.alas = alas;
        this.tinggiSegi = tinggiSegi;
    }

    public float getAlas() {
        return alas;
    }

    public void setAlas(float alas) {
        this.alas = alas;
    }

    public float getTinggiSegi() {
        return tinggiSegi;
    }

    public void setTinggiSegi(float tinggiSegi) {
        this.tinggiSegi = tinggiSegi;
    }

    @Override
    public float getVolume() {
        return (alas * tinggiSegi * getTinggi() / 3);
    }
}

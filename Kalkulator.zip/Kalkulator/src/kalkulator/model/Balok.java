/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kalkulator.model;
/**
 *
 * @author oktaviacitra
 */
public class Balok extends BangunRuang {
    private float panjang, lebar;

    public Balok() {
    }

    public Balok(float panjang, float lebar) {
        this.panjang = panjang;
        this.lebar = lebar;
    }

    public Balok(float panjang, float lebar, float tinggi) {
        super(tinggi);
        this.panjang = panjang;
        this.lebar = lebar;
    }
    
    public float getPanjang() {
        return panjang;
    }

    public void setPanjang(float panjang) {
        this.panjang = panjang;
    }

    public float getLebar() {
        return lebar;
    }

    public void setLebar(float lebar) {
        this.lebar = lebar;
    }
    
    @Override
    public float getVolume() {
        return (panjang * lebar * getTinggi());
    }
    
}

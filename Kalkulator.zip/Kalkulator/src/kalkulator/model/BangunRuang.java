/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kalkulator.model;
/**
 *
 * @author oktaviacitra
 */
public abstract class BangunRuang {
    private float tinggi;

    public BangunRuang() {
    }

    public BangunRuang(float tinggi) {
        this.tinggi = tinggi;
    }

    public float getTinggi() {
        return tinggi;
    }

    public void setTinggi(float tinggi) {
        this.tinggi = tinggi;
    }
    
    public abstract float getVolume();
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kalkulator.model;
/**
 *
 * @author oktaviacitra
 */
public class Kubus extends BangunRuang{
    private float sisi;

    public Kubus() {
    }

    public Kubus(float sisi) {
        this.sisi = sisi;
    }

    public Kubus(float sisi, float tinggi) {
        super(tinggi);
        this.sisi = sisi;
    }

    public float getSisi() {
        return sisi;
    }

    public void setSisi(float sisi) {
        this.sisi = sisi;
    }

    @Override
    public float getVolume() {
        return (sisi * getTinggi());
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
/**
 *
 * @author oktaviacitra
 */
@Entity
public class Transaction {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    private String time;
    private int total;
    @ManyToOne
    private Cashier cashier;
    @ManyToOne
    private Good good;
    public Transaction(){
        super();
    }
    public Transaction(int id, String time, int total){
        this.id = id;
        this.time = time;
        this.total = total;
    }
    public void setId(int id){
        this.id = id;
    }
    public int getId(){
        return id;
    }
    public void setTime(String time){
        this.time = time;
    }
    public String getTime(){
        return time;
    }
    public void setTotal(int total){
        this.total = total;
    }
    public int getTotal(){
        return this.total;
    }
    public void setCashier(Cashier cashier) {
        this.cashier = cashier;
    }
    public void setGood(Good good) {
        this.good = good;
    }
    public Cashier getCashier() {
        return cashier;
    }
    public Good getGood() {
        return good;
    }
    
}

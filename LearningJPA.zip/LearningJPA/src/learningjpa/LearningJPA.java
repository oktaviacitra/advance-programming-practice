/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package learningjpa;
import java.util.List;
import learningjpa.dao.DaoUser;
import learningjpa.model.User;
/**
 *
 * @author oktaviacitra
 */
public class LearningJPA {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        DaoUser daoUser = new DaoUser();
        User user = new User();
        user.setNama("Fahrul");
        daoUser.save(user);
        List<User> result = daoUser.findAll();
        for(int i = 0; i < result.size(); i++){
            User printUser = result.get(i);
            System.out.println(printUser.getId() + "-" + printUser.getNama());
        }
    }
    
}

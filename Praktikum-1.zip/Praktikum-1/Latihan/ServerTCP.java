import java.io.*;
import java.net.*;
import java.util.*;
public class ServerTCP {
    public static void main(String[] args){
        ServerSocket serverSocket;
        int port = 2306;
        int timeOut = 60000;
        try {
            //init ServerSocket
            serverSocket = new ServerSocket(port);
            //set server timeout
		    serverSocket.setSoTimeout(timeOut);
            //waiting for client
            System.out.println("Waiting for client on port ");
            Socket server = serverSocket.accept();
            //getting Input Stream
            System.out.println("Connected to client " + server.getRemoteSocketAddress());
            //get client Socket Address
            DataInputStream in = new DataInputStream(server.getInputStream());
            //write client message
            System.out.println("Client says "+ in.readUTF());
            //getting output stream
            DataOutputStream out = new DataOutputStream(server.getOutputStream());
            out.writeUTF("Thank you for connecting to "+ server.getLocalSocketAddress() /*get server socket Address and send to client*/ + "\nGoodBye!");
            //closing server
            server.close();
        } catch (IOException ex) {
            System.out.println("Error");
        }
    }
}

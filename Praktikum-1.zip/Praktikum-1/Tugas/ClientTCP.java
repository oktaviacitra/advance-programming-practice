import java.io.*;
import java.net.*;
import java.util.*;
public class ClientTCP {
    public static void main(String args[]){
        String serverName = "localhost";
        int port = 2306;
        try{
            System.out.println("Connecting to "+ serverName + " on port "+ port);
            //create socket and connect to server
            Socket client = new Socket(serverName, port);
            System.out.println("Just connected to "+ client.getRemoteSocketAddress());
            //input message
            String strInput;
            do{
                System.out.print("Enter your message: ");
                Scanner scanner = new Scanner(System.in);
                strInput = scanner.nextLine();
                //create stream to send data to server
                OutputStream outToServer = client.getOutputStream();
                DataOutputStream out = new DataOutputStream(outToServer);
                out.writeUTF(strInput);
                //out.writeUTF("Hello, I am "+client.getLocalSocketAddress());
            }while(!strInput.equals("exit"));
            //read InputStream from server
            InputStream inFromServer = client.getInputStream();
            DataInputStream in = new DataInputStream(inFromServer);
            //read server message
            System.out.println("Server says "+ in.readUTF());
            client.close();
        }catch(IOException e){
            e.printStackTrace();
        }
    }
}

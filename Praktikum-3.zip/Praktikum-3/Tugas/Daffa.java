import java.io.*;
import java.net.*;
import java.util.*;
class Daffa
{
	public static void main(String args[]) throws Exception
	{
		BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));
		DatagramSocket clientSocket = new DatagramSocket();
        InetAddress IPAddress = InetAddress.getByName("localhost");
        int kondisi;
        while (true) {
            byte[] sendData = new byte[1024];
            byte[] receiveData = new byte[1024];
            System.out.print("DAFFA\t: ");
            String sentence = inFromUser.readLine();
            String reverse = "";
            if(sentence.equalsIgnoreCase("goodnight")){
                reverse = "Daffa said " + sentence +"... connection ended";
                kondisi = 1;
            }else{
                int n = sentence.length() - 1;
                for(int i=n; i>=0; i--)
                    reverse = reverse + sentence.charAt(i);
                kondisi = 0;
            }
            sendData = reverse.getBytes();
            DatagramPacket sendPacket = new DatagramPacket(sendData,sendData.length, IPAddress, 9876);
            clientSocket.send(sendPacket);
            if(kondisi == 1)
                break;
            else{
                DatagramPacket receivePacket = new DatagramPacket(receiveData,receiveData.length);
                clientSocket.receive(receivePacket);
                String modifiedSentence = new String(receivePacket.getData());
                System.out.println("CITRA\t: " + modifiedSentence);
            }
        }
		clientSocket.close();
	}
}

import java.io.*;
import java.net.*;
import java.util.*;
class Citra
{
	public static void main(String args[]) throws Exception
	{
		BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));
        DatagramSocket serverSocket = new DatagramSocket(9876);
        int kondisi;
        while (true) {
            byte[] sendData = new byte[1024];
            byte[] receiveData = new byte[1024];
            DatagramPacket receivePacket = new DatagramPacket(receiveData,receiveData.length);
            serverSocket.receive(receivePacket);
            String modifiedSentence = new String(receivePacket.getData());
            System.out.println("DAFFA\t: " + modifiedSentence);
            System.out.print("CITRA\t: ");
            String sentence = inFromUser.readLine();
            String reverse = "";
            if(sentence.equalsIgnoreCase("goodnight")){
                reverse = "Citra said " + sentence +"... connection ended";
                kondisi = 1;
            }else{
                int n = sentence.length() - 1;
                for(int i=n; i>=0; i--)
                    reverse = reverse + sentence.charAt(i);
                kondisi = 0;
            }
            sendData = reverse.getBytes();
            InetAddress IPAddress = receivePacket.getAddress();
            int port = receivePacket.getPort();
            DatagramPacket sendPacket = new DatagramPacket(sendData,sendData.length, IPAddress, port);
            serverSocket.send(sendPacket);
            if(kondisi == 1)
                break;
        }
		serverSocket.close();
	}
}

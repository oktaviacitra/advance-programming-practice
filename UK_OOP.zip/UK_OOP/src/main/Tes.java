/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;
import model.Pegawai;
import model.Manager;
import java.io.IOException;
/**
 * @modifier public
 * @version 1.0
 * @author oktaviacitra
 */
public class Tes {
    
    /**
     * @modifier public
     * @param peg
     */
    public static void Proses(Pegawai peg) {
        
        if(peg instanceof Manager && peg instanceof Pegawai)
            System.out.println("Manager");
        else
            System.out.println("Pegawai");
    }

    /**
     * @param args Unused.
     * @throws java.io.IOException
     * @modifier public
     */
    public static void main(String[] args) throws IOException {
        Manager manager = new Manager("TI", "04", "Citra");
        Proses(manager);
        Pegawai pegawai = new Pegawai("05", "Ega");
        Proses(pegawai);
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;
import java.io.IOException;
import model.Pegawai;
/**
 * @modifier public
 * @version 1.0
 * @author oktaviacitra
 */
public class Main {

    /**
     * @modifier public
     * @param args
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        Pegawai pegawai1 = new Pegawai("01", "Ani");
        System.out.println("Pegawai-1\nNIP\t: " + pegawai1.getNip());
        System.out.println("Nama\t: " + pegawai1.getNama());
        Pegawai pegawai2 = new Pegawai("02", "Budi");
        System.out.println("Pegawai-1\nNIP\t: " + pegawai2.getNip());
        System.out.println("Nama\t: " + pegawai2.getNama());
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;
import java.io.IOException;
import model.Manager;
/**
 * @modifier public
 * @version 1.0
 * @author oktaviacitra
 */
public class Main2 {

    /**
     * @modifier public
     * @param args
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        Manager m1 = new Manager("TI", "03", "Candra");
        System.out.println("Departemen\t: " + m1.getDepartemen());
        System.out.println("NIP\t: " + m1.getNip());
        System.out.println("Nama\t: " + m1.getNama());
    }
}

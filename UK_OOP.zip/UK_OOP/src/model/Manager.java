/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 * @modifier public
 * @version 1.0
 * @author oktaviacitra
 */
public class Manager extends Pegawai {
    /**
     * @modifier private
     */
    private String departemen;

    /**
     * @modifier public
     * @param nip
     * @param nama
     * @param departemen
     */
    public Manager(String nip, String nama, String departemen) {
        super(nip, nama);
        this.departemen = departemen;
    }

    /**
     * @modifier public
     * @param departemen
     */
    public void setDepartemen(String departemen) {
        this.departemen = departemen;
    }

    /**
     * @modifier public
     * @return
     * @see String
     */
    public String getDepartemen() {
        return departemen;
    }
    
    
}

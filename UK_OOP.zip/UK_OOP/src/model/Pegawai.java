/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 * @modifier public
 * @version 1.0
 * @author oktaviacitra
 */
public class Pegawai {
    
    /**
     * @modifier private
     */
    private String nip;
    
    /**
     * @modifier private
     */
    private String nama;

    /**
     * @modifier public
     * @param nip
     * @param nama
     */
    public Pegawai(String nip, String nama) {
        this.nip = nip;
        this.nama = nama;
    }

    /**
     * @modifier public
     * @param nip
     */
    public void setNip(String nip) {
        this.nip = nip;
    }

    /**
     * @modifier public
     * @param nama
     */
    public void setNama(String nama) {
        this.nama = nama;
    }

    /**
     * @modifier public
     * @return
     * @see String
     */
    public String getNip() {
        return nip;
    }

    /**
     * @modifier public
     * @return
     * @see String
     */
    public String getNama() {
        return nama;
    }
    
}

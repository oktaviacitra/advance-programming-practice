import javax.swing.*;   
import java.io.*;
import java.net.*; 
public class ShowContact{ 
    public static void main(String[] args) {
        int port = 2002;
        JFrame f = new JFrame();
        try {
            ServerSocket ss = new ServerSocket(port);
            Socket s = ss.accept();
            InputStream is = s.getInputStream();
            ObjectInputStream ois = new ObjectInputStream(is);
            Contact contact = (Contact) ois.readObject();
            if (contact != null) {
                String data[][]={{String.valueOf(contact.id), contact.name, contact.address, contact.phone}};    
                String column[]={"ID","NAME","ADDRESS","PHONE"};         
                JTable jt=new JTable(data,column);    
                jt.setBounds(30,40,200,300);          
                JScrollPane sp=new JScrollPane(jt);    
                f.add(sp);          
                f.setSize(300,400);    
                f.setVisible(true);
                String dataContact = contact.id + ";" + contact.name + ";" + contact.address + ";" + contact.phone + "|";
                PrintWriter writer = new PrintWriter("Server.txt", "UTF-8");
                writer.print(dataContact);
                writer.close();
            }
            System.out.println((String) ois.readObject());
            is.close();
            s.close();
            ss.close();
        } catch (Exception e) {
            e.printStackTrace();
        }       
    }      
} 
import javax.swing.*;
import java.net.*;
import java.io.*;
public class InputContact {
    public static void main(String[] args) {
        try {
            int id = 0;
            while(true){
                JTextField nameField = new JTextField(15);
                JTextField addressField = new JTextField(15);
                JTextField phoneField = new JTextField(15);
            
                JPanel myPanel = new JPanel();
                myPanel.add(new JLabel("Name"));
                myPanel.add(nameField);
                myPanel.add(Box.createHorizontalStrut(5)); // a spacer
                myPanel.add(new JLabel("Address"));
                myPanel.add(addressField);
                myPanel.add(Box.createHorizontalStrut(5));
                myPanel.add(new JLabel("Phone"));
                myPanel.add(phoneField);
            
                int result = JOptionPane.showConfirmDialog(null, myPanel, "Please Enter Name, Address, and Phone", JOptionPane.OK_CANCEL_OPTION);
                if (result == JOptionPane.OK_OPTION) {
                    Socket s = new Socket("localhost", 2002);
                    OutputStream os = s.getOutputStream();
                    ObjectOutputStream oos = new ObjectOutputStream(os);
                    String name = nameField.getText();
                    String address = addressField.getText();
                    String phone = phoneField.getText();
                    Contact contact = new Contact(id, name, address, phone);
                    oos.writeObject(contact);
                    id++;
                    //Initialize socket
                    oos.close();
                    os.close();
                    s.close();
                }else if(result == JOptionPane.CANCEL_OPTION){
                    Socket socket = new Socket(InetAddress.getByName("localhost"), 5000);
                    byte[] contents = new byte[10000];
                    //Initialize the FileOutputStream to the output file's full path.
                    FileOutputStream fos = new FileOutputStream("Client.txt");
                    BufferedOutputStream bos = new BufferedOutputStream(fos);
                    InputStream is = socket.getInputStream();
                    //No of bytes read in one read() call
                    int bytesRead = 0;
                    while((bytesRead=is.read(contents))!=-1)
                        bos.write(contents, 0, bytesRead);
                    bos.flush();
                    socket.close();
                    bos.close();
                }else{
                    System.exit(0);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
      }
} 
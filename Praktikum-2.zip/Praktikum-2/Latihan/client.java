import java.net.*;
import java.util.Scanner;
import java.io.*;
public class client {
    public static void main(String args[]) {
        try {
            Socket s = new Socket("localhost", 2002);
            OutputStream os = s.getOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(os);
            Scanner scanner = new Scanner(System.in);
            System.out.println("\tInput Kontak");
            System.out.println("\t============\n");
            System.out.print("Masukkan nama\t: ");
            String name = scanner.nextLine();
            System.out.print("Masukkan alamat\t: ");
            String address = scanner.nextLine();
            System.out.print("Masukkan telpon\t: ");
            String phone = scanner.nextLine();
            int id = 0;
            Contact con = new Contact(id, name, address, phone);
            oos.writeObject(con);
            System.out.println("data is sent");
            //oos.writeObject(new String("another object from the client"));
            oos.close();
            os.close();
            s.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
import java.io.*;
class Contact implements Serializable{
    int id;
    String name;
    String address;
    String phone;
    public Contact(int id, String name, String address, String phone){
        this.id=id;
        this.name=name;
        this.address=address;
        this.phone=phone;
    }
}
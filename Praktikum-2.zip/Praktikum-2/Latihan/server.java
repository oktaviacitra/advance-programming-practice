import java.io.*;
import java.net.*;
public class server {
    public static void main(String args[]) {
        int port = 2002;
        try {
            ServerSocket ss = new ServerSocket(port);
            Socket s = ss.accept();
            InputStream is = s.getInputStream();
            ObjectInputStream ois = new ObjectInputStream(is);
            Contact con = (Contact) ois.readObject();
            System.out.println("\tDaftar Kontak");
            System.out.println("\t=============\n");
            if (con != null) {
                System.out.println("id\t: "+con.id);
                System.out.println("name\t: "+con.name);
                System.out.println("address\t: "+con.address);
                System.out.println("phone\t: "+con.phone);
            }
            //System.out.println((String) ois.readObject());
            is.close();
            s.close();
            ss.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}